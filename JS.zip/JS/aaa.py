y = input()
x = input()
print(x+y)

