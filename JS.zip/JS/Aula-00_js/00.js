alert("Você acaba de ganhar uma coxinha!");

let nome = prompt("nome?");
alert("seu nome é " +  nome);

let bolo = confirm("gosta de bolo?");
alert("resposta" +  bolo);

// função
function botao(){
    alert("NAO ");
}