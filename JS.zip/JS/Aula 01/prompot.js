const form = document.getElementById('myform')


console.log(form)
// form.addEventListener('submit', function(event){
//     event.preventDefault()
// //     const nomeUser = document.getElementById('usuario').value
// //     window.alert(`Olá ${nomeUser},  seu formulário foi enviado com Sucesso!`)
// })

