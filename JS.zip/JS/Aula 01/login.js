let nome = 'E_nicolly'
let senha = '@E_nicollyy3'

if(nome == 'E_nicollyy' && senha == '@E_nicollyy3'){
    console.log("Acesso liberado")
}

else{
    console.log("Acesso Negado")
}