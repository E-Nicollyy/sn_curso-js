function barueri(){
    alert("Escola SENAI José Ephim Mindlin. Edereço: Alameda Wagih Salles Nemer, 124 - Centro - Barueri/SP, 06401-134")
}

function osasco(){
    alert("Escola SENAI Nadir Dias de Figueiredo. Endereço: Rua Ari Barroso, 305 - Presidente Altino - Osasco/SP, 06216-901")
}

function itapevi(){
    alert("Endereço: Av. Rubens Caramez, 279 - Cohab - St. D, Itapevi - SP ")
}
function jandira(){
    alert(" Escola SENAI Prof. Vicente Amato. Endereço: Rua Elton Silva, 905 - Centro - Jandira/SP, 06600-025 ")
}