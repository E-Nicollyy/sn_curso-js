// const menuDrop = document.getElementById('menuDrop')

// function activaMenu(){
//     menuDrop.classList.toggle('emilly')
// }

const remove =  document.getElementById('emilly')